* N players: Reactive
* WF pairwise comparison
* two types teachers: 1 GTFT vs several ALLD 


      program sab
      implicit real*8 (a-h,o-z)
      character*10 slurm
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)

      parameter (n=1000,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (c=0.8d+00,u=0.1d+00*rrn,be=10.d+00,beta=be*rrn1)
      parameter (itend=10**5,init=itend/2)
      parameter (pt1=0.9999d+00,qt1=0.01d+00)
      parameter (pt2=0.0001d+00,qt2=0.0001d+00)
        
      dimension p(n),q(n),r(n),f(n),pn(n),qn(n)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      iseed=5055+isl
      call init_genrand(iseed)

      open (unit=3,file=slurm)

* numer of runs 

      isum=0      
      do malld=0,100,5
      do im=1,50
      isum=isum+1
      if (isl.eq.isum) goto 15
      enddo
      enddo

 15   continue

      itft=malld+1
      m1=malld+2

    
      
* initial population    

      z=o0
      eff=o0 


      do i=1,malld
      p(i)=pt2
      q(i)=qt2
      r(i)=pt2-qt2
      enddo

      p(itft)=pt1
      q(itft)=qt1
      r(itft)=pt1-qt1
      

      do i=m1,n
      p(i)=genrand_real3()
      q(i)=genrand_real3()
      r(i)=p(i)-q(i)
      enddo 


* learning dynamics

      do it=1,itend 

* calculate payoff, do not play against self

      do i=1,n
      f(i)=o0
      enddo

      do i=1,n      
      do j=1,i-1      

      den=o1/(o1-r(i)*r(j))
      s1=(q(j)*r(i)+q(i))*den
      s2=(q(i)*r(j)+q(j))*den

      f(i)=f(i)+s2-c*s1
      f(j)=f(j)+s1-c*s2

      enddo
      enddo


* sample 

      if (it.gt.init) then
      z=z+o1
      do i=1,n      
      eff=eff+f(i)
      enddo
      endif

* update all players i=m1,n with PW comparison or mutation

      do i=m1,n 
  
      if (genrand_real3().lt.u) then 

      pn(i)=genrand_real3()      
      qn(i)=genrand_real3()      

      else 

      j = 1 + int(genrand_real3()*rn)

      prob=o1/(o1+dexp(-beta*(f(j)-f(i))))

      if (genrand_real3().lt.prob) then
      pn(i)=p(j)
      qn(i)=q(j)
      else     
      pn(i)=p(i)
      qn(i)=q(i)      
      endif

      endif


      enddo


* new generation i=m1,n

      do i=m1,n
      p(i)=pn(i)
      q(i)=qn(i)
      r(i)=p(i)-q(i)
      enddo
 
      enddo 


* output

      
      eff=eff*rrn*rrn1/z
      eff=eff/(o1-c)

      write (3,'(i8,f12.8)') malld,eff
      call flush(3)

      stop
      end