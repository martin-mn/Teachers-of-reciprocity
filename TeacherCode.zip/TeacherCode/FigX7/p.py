import pandas as pd
import matplotlib.pyplot as plt

def plot_grouped_bar():
    # 1. Read the input file
    # Assuming 'c.out' is space or tab delimited. 
    # If it is comma-separated, change delim_whitespace=True to sep=','
    try:
        # We assign column names manually since .out files often lack headers
        df = pd.read_csv('c.out', delim_whitespace=True, header=None, names=['x', 'y', 'z'])
    except FileNotFoundError:
        print("Error: The file 'c.out' was not found in the current directory.")
        return

    # 2. Reshape the data for a grouped bar chart
    # This sets 'x' as the groups on the X-axis, 'y' as the different colored bars, and 'z' as the height
    pivot_df = df.pivot(index='x', columns='y', values='z')

    # 3. Create the plot
    # pandas automatically plots separate columns as differently colored bars side-by-side
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # We use a built-in colormap, 'Set1' or 'viridis' work nicely for 3 distinct colors
    pivot_df.plot(kind='bar', ax=ax, colormap='Set2', edgecolor='black')

    # 4. Customize the chart aesthetics
    ax.set_title('GTFT teacher', fontsize=14)
    ax.set_xlabel('Cost, c', fontsize=14)
    ax.set_ylabel('Payoff (scaled)', fontsize=14)
    
    # Format the legend and X-axis ticks
    ax.legend(title='Discount')
    plt.xticks(rotation=0) # Keeps X-axis labels horizontal
    plt.grid(axis='y', linestyle='--', alpha=0.7) # Adds a subtle background grid

    # Adjust layout so labels don't get cut off
    plt.tight_layout()

    # 5. Save the output as a PDF file
    output_filename = 'output_chart.pdf'
    plt.savefig(output_filename, format='pdf')
    print(f"Bar chart successfully saved as '{output_filename}'")

    # (Optional) Uncomment the line below if you also want to see the plot on your screen
    # plt.show()

if __name__ == "__main__":
    plot_grouped_bar()