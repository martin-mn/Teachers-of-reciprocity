import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker  # <-- ADDED for integer ticks

# --- Configuration ---
input_filename = 'c.out'  # Replace with your actual file name
output_filename = 'output_plot.pdf'

# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size (e.g., 'No teacher')
    'axes.labelsize': 18,     # X and Y axis label font size ('Cost, c', 'Payoff')
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})
# -------------------------------------

# 1. Read the data
# Note: If your file is comma-separated, change sep='\s+' to sep=','
# We assume the file doesn't have headers. If it does, remove header=None
df = pd.read_csv(input_filename, sep='\s+', header=None, names=['x', 'y'])

# 2. Calculate the average 'y' for each 'x'
# groupby('x') automatically sorts the x values, which is perfect for a line plot
avg_df = df.groupby('x')['y'].mean().reset_index()

# 3. Create the plot
plt.figure(figsize=(6, 4))

# Do a scatter plot of all the raw data points
# alpha=0.5 makes points slightly transparent so you can see overlapping points
plt.scatter(df['x'], df['y'], color='blue', alpha=0.5, s=30)

# Draw a line through the average values
plt.plot(avg_df['x'], avg_df['y'], color='red', linewidth=2, marker='o')

# 4. Add labels, title, and legend
plt.xlabel("Number of ALLD teachers", fontsize=14)
plt.ylabel("Payoff", fontsize=14)
plt.title("1 GTFT teacher vs ALLD teachers", fontsize=14)

# <-- ADDED: Force x-axis to only show integer ticks -->
plt.gca().xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

#plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)

# 5. Save to PDF and optionally display
plt.tight_layout() # Ensures labels don't get cut off
plt.savefig(output_filename, format='pdf')
print(f"Plot successfully saved to {output_filename}")

# Uncomment the next line if you also want a window to pop up and show the plot
# plt.show()