* N players: PGG with 4 players
* WF pairwise comparison

      program sab
      implicit real*8 (a-h,o-z)
      character*10 slurm
      
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)

      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (u=0.1d+00*rrn,be=10.d+00)
      parameter (itend=10**4,init=itend/2)
        
      dimension p(n,0:3),f(n),pn(n,0:3)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      iseed=2312+isl
      call init_genrand(iseed)

      open (unit=3,file=slurm)

* vary rmu
      
      rmu=o1+dble(isl)*0.1d+00

      
* initial  

      z=o0
      eff=o0 

* runs

      do irun=1,100
 
      
      p(1,0)=0.01d+00
      p(1,1)=1.d+00/3.d+00
      p(1,2)=2.d+00/3.d+00
      p(1,3)=0.9999d+00
      

      do i=2,n
      do k=0,3
      p(i,k)=genrand_real3()
      enddo
      enddo 


* learning dynamics

      do it=1,itend 

* calculate payoff

      call PGG(p,f,rmu)

* sample 

      if (it.gt.init) then
      z=z+o1
      do i=1,n      
      eff=eff+f(i)
      enddo
      endif

* update all players i=m1,n with PW comparison or mutation

      do i=2,n 
  
      if (genrand_real3().lt.u) then 

      do k=0,3
      pn(i,k)=genrand_real3()      
      enddo      

      else 

      j = 1 + int(genrand_real3()*rn)

      prob=o1/(o1+dexp(-be*(f(j)-f(i))))

      if (genrand_real3().lt.prob) then

      do k=0,3
      pn(i,k)=p(j,k)
      enddo 

      else  

      do k=0,3
      pn(i,k)=p(i,k)
      enddo 
      
      endif
      endif


      enddo


* new generation i=2,n

      do i=2,n
      do k=0,3
      p(i,k)=pn(i,k)
      enddo
      enddo
 
      enddo 

      enddo


* output

      
      eff=eff*rrn/z

      if (rmu.gt.o1) eff=eff/(rmu-o1)

      write (3,'(2f12.8)') rmu,eff
      call flush(3)

      stop
      end


C=======================================================================
      SUBROUTINE PGG(P, F, R)
C=======================================================================
C     Calculates the expected payoff in an infinitely repeated public
C     goods game without discounting.
C
C     Inputs:
C       P(N,0:3) : Double Precision. P(I,K) is the probability that
C                  player I cooperates in this round given that K of
C                  their co-players cooperated in the previous round.
C       R        : Double Precision. The multiplication factor.
C
C     Outputs:
C       F(N)     : Double Precision. The expected payoff for each player.
C=======================================================================
C     --- Subroutine Parameters ---
      INTEGER N, M
C     N is the total number of players.
      PARAMETER (N = 100)
C     M is the number of random 4-player groups formed.
      PARAMETER (M = 1000)

C     --- Dummy Arguments ---
      DOUBLE PRECISION P(N, 0:3), F(N), R

C     --- Local Variables ---
      INTEGER COUNTS(N)
      INTEGER I, J, K, ITER
      INTEGER IDX(4)
C     ID_NEXT/C_NEXT used for decoding next states in transition matrix.
C     ID_STATE/C_STATE used for decoding states in the payoff loop,
C     avoiding reuse of ID_NEXT/C_NEXT with different semantics.
      INTEGER S, S_CURR, S_NEXT, ID_CURR, ID_NEXT, ID_STATE
      INTEGER M_IDX, SUM_C, K_COOP
      INTEGER C_CURR(4), C_NEXT(4), C_STATE(4)
      DOUBLE PRECISION RHO(4), PROB, PAYOFF
      DOUBLE PRECISION TMAT(16,16), AMAT(16,16), BMAT(16), PI_VEC(16)
C     PIVMAX renamed from MAXVAL to avoid shadowing the Fortran 90+
C     intrinsic array function of the same name.
      DOUBLE PRECISION PIVMAX, FACTOR, SUM_VAL, TEMP
      INTEGER PIVOT

C     Random number generator function
      DOUBLE PRECISION RND
      EXTERNAL RND
      INTEGER ISEED
      SAVE ISEED
C     The seed is fixed for reproducibility: every run produces the same
C     sequence of random groups. To vary results between runs, change
C     ISEED here or pass it as an argument before calling PGG.
      DATA ISEED / 123456789 /

C     Initialize payoffs and counts
      DO 10 I = 1, N
        F(I) = 0.0D0
        COUNTS(I) = 0
   10 CONTINUE

C     --- Main Loop: Form M random groups of 4 players ---
      DO 100 ITER = 1, M

C       Select 4 distinct players randomly.
C       IDX(1) needs no retry label: any player index is valid.
        IDX(1) = 1 + INT(RND(ISEED) * N)
   21   IDX(2) = 1 + INT(RND(ISEED) * N)
        IF (IDX(2) .EQ. IDX(1)) GO TO 21
   22   IDX(3) = 1 + INT(RND(ISEED) * N)
        IF (IDX(3) .EQ. IDX(1) .OR. IDX(3) .EQ. IDX(2)) GO TO 22
   23   IDX(4) = 1 + INT(RND(ISEED) * N)
        IF (IDX(4) .EQ. IDX(1) .OR. IDX(4) .EQ. IDX(2) .OR.
     +      IDX(4) .EQ. IDX(3)) GO TO 23

C       Build 16x16 Transition Matrix (TMAT) for the Markov Chain
        DO 40 S_CURR = 1, 16
          ID_CURR = S_CURR - 1
C         Determine who cooperated in the current state (Bits 0 to 3)
          C_CURR(1) = MOD(ID_CURR, 2)
          C_CURR(2) = MOD(ID_CURR / 2, 2)
          C_CURR(3) = MOD(ID_CURR / 4, 2)
          C_CURR(4) = MOD(ID_CURR / 8, 2)

          SUM_C = C_CURR(1) + C_CURR(2) + C_CURR(3) + C_CURR(4)

C         Find probability (RHO) that each player cooperates next round
          DO 30 M_IDX = 1, 4
            K_COOP = SUM_C - C_CURR(M_IDX)
            RHO(M_IDX) = P(IDX(M_IDX), K_COOP)
C           Clamp probabilities strictly away from 0 and 1 to ensure
C           the Markov chain is ergodic and the stationary distribution
C           is unique. When pure strategies (P=0 or P=1) are used, this
C           introduces a systematic bias of O(1e-8) in the stationary
C           distribution.
            IF (RHO(M_IDX) .LT. 1.0D-8) RHO(M_IDX) = 1.0D-8
            IF (RHO(M_IDX) .GT. (1.0D0 - 1.0D-8))
     +          RHO(M_IDX) = 1.0D0 - 1.0D-8
   30     CONTINUE

C         Calculate transition probability to all 16 possible next states
          DO 35 S_NEXT = 1, 16
            ID_NEXT = S_NEXT - 1
            C_NEXT(1) = MOD(ID_NEXT, 2)
            C_NEXT(2) = MOD(ID_NEXT / 2, 2)
            C_NEXT(3) = MOD(ID_NEXT / 4, 2)
            C_NEXT(4) = MOD(ID_NEXT / 8, 2)

            PROB = 1.0D0
            DO 32 M_IDX = 1, 4
              IF (C_NEXT(M_IDX) .EQ. 1) THEN
                PROB = PROB * RHO(M_IDX)
              ELSE
                PROB = PROB * (1.0D0 - RHO(M_IDX))
              ENDIF
   32       CONTINUE
            TMAT(S_CURR, S_NEXT) = PROB
   35     CONTINUE
   40   CONTINUE

C       Construct the linear system (I - TMAT)^T * PI_VEC = 0
        DO 51 J = 1, 16
          DO 50 K = 1, 16
            AMAT(J, K) = -TMAT(K, J)
   50     CONTINUE
          AMAT(J, J) = AMAT(J, J) + 1.0D0
          BMAT(J) = 0.0D0
   51   CONTINUE

C       Replace the 16th equation with the sum(PI_VEC) = 1 condition
        DO 52 K = 1, 16
          AMAT(16, K) = 1.0D0
   52   CONTINUE
        BMAT(16) = 1.0D0

C       Solve AMAT * PI_VEC = BMAT using Gaussian elimination
C       with partial pivoting (n-1 = 15 forward elimination steps)
        DO 67 I = 1, 15
          PIVMAX = DABS(AMAT(I,I))
          PIVOT = I
          DO 60 J = I+1, 16
            IF (DABS(AMAT(J,I)) .GT. PIVMAX) THEN
              PIVMAX = DABS(AMAT(J,I))
              PIVOT = J
            ENDIF
   60     CONTINUE

          IF (PIVOT .NE. I) THEN
C           Swap rows I and PIVOT from column I onward.
C           Columns 1..I-1 are already zeroed in all rows >= I.
            DO 61 J = I, 16
              TEMP = AMAT(I,J)
              AMAT(I,J) = AMAT(PIVOT,J)
              AMAT(PIVOT,J) = TEMP
   61       CONTINUE
            TEMP = BMAT(I)
            BMAT(I) = BMAT(PIVOT)
            BMAT(PIVOT) = TEMP
          ENDIF

          DO 66 J = I+1, 16
            FACTOR = AMAT(J,I) / AMAT(I,I)
            DO 62 K = I, 16
              AMAT(J,K) = AMAT(J,K) - FACTOR * AMAT(I,K)
   62       CONTINUE
            BMAT(J) = BMAT(J) - FACTOR * BMAT(I)
   66     CONTINUE
   67   CONTINUE

C       Back substitution
        PI_VEC(16) = BMAT(16) / AMAT(16,16)
        DO 65 I = 15, 1, -1
          SUM_VAL = 0.0D0
          DO 64 J = I+1, 16
            SUM_VAL = SUM_VAL + AMAT(I,J) * PI_VEC(J)
   64     CONTINUE
          PI_VEC(I) = (BMAT(I) - SUM_VAL) / AMAT(I,I)
   65   CONTINUE

C       Calculate expected long-run payoff for each player in group.
C       ID_STATE/C_STATE decode the current game state S, distinct from
C       ID_NEXT/C_NEXT which decode the next state in the transition loop.
        DO 72 S = 1, 16
          ID_STATE = S - 1
          C_STATE(1) = MOD(ID_STATE, 2)
          C_STATE(2) = MOD(ID_STATE / 2, 2)
          C_STATE(3) = MOD(ID_STATE / 4, 2)
          C_STATE(4) = MOD(ID_STATE / 8, 2)

          SUM_C = C_STATE(1) + C_STATE(2) + C_STATE(3) + C_STATE(4)

          DO 71 M_IDX = 1, 4
            PAYOFF = R * DBLE(SUM_C) / 4.0D0 - DBLE(C_STATE(M_IDX))
            F(IDX(M_IDX)) = F(IDX(M_IDX)) + PI_VEC(S) * PAYOFF
   71     CONTINUE
   72   CONTINUE

C       Update play counts
        DO 73 I = 1, 4
          COUNTS(IDX(I)) = COUNTS(IDX(I)) + 1
   73   CONTINUE

  100 CONTINUE

C     --- Average the expected payoffs ---
      DO 110 I = 1, N
        IF (COUNTS(I) .GT. 0) THEN
          F(I) = F(I) / DBLE(COUNTS(I))
        ELSE
          F(I) = 0.0D0
        ENDIF
  110 CONTINUE

      RETURN
      END

C=======================================================================
      DOUBLE PRECISION FUNCTION RND(ISEED)
C=======================================================================
C     Portable Linear Congruential Generator returning uniform [0,1).
C     Uses Schrage's method to prevent 32-bit integer overflow.
C     Parameters: multiplier a=16807, modulus m=2147483647 (Mersenne
C     prime), with Schrage decomposition q=m/a=127773, r=mod(m,a)=2836.
C=======================================================================
      INTEGER ISEED
      INTEGER Q, R_CONST, HI, LO, TEST

      Q      = 127773
      R_CONST = 2836
      HI   = ISEED / Q
      LO   = MOD(ISEED, Q)
      TEST = 16807 * LO - R_CONST * HI

      IF (TEST .GT. 0) THEN
        ISEED = TEST
      ELSE IF (TEST .LT. 0) THEN
        ISEED = TEST + 2147483647
      ELSE
C       TEST = 0 is a pathological fixed point of the recurrence.
C       Recovery: set ISEED = 1 (the smallest valid seed).
C       This branch should never be reached for any valid starting seed
C       because 0 is not in the multiplicative group mod 2147483647.
        ISEED = 1
      ENDIF

      RND = DBLE(ISEED) / 2147483647.0D0

      RETURN
      END