import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Read the data
# Assuming the file is space or tab separated. 
# If your file has a header row, change header=None to header=0
df = pd.read_csv('d.out', delim_whitespace=True, names=['p1', 'p2', 'p3', 'p4', 'f'], header=None)

# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size (e.g., 'No teacher')
    'axes.labelsize': 18,     # X and Y axis label font size ('Cost, c', 'Payoff')
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})


# 2. Define the 9 specific subsets (lower_bound, upper_bound, label)
# None is used for open-ended bounds (e.g., f < 0.01 or f >= 0.95)
ranges = [
    (None, 0.10, "0<f<0.1"),
    (0.10, 0.20, "0.1<f<0.2"),
    (0.20, 0.30, "0.2<f< 0.3"),
    (0.30, 0.50, "0.3<f< 0.5"),
    (0.50, 0.70, "0.5<f< 0.7"),
    (0.70, 0.90, "0.7<f< 0.9"),
    (0.90, 0.95, "0.9<f< 0.95"),
    (0.95, 0.99, "0.95<f<0.99"),
    (0.99, None, "0.99<f<1")
]

# 3. Set up the figure and axes (3 rows, 3 columns)
fig, axes = plt.subplots(nrows=3, ncols=3, figsize=(14, 14), sharey=True, constrained_layout=True)
axes = axes.flatten() # Flatten to a 1D array for easy iteration

# Variables and styling
variables = ['p1', 'p2', 'p3', 'p4']
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'] # Blue, Orange, Green, Red
x_pos = np.arange(len(variables))

# 4. Loop through the 12 defined ranges
for i, (lower, upper, label) in enumerate(ranges):
    # Filter the dataframe safely catching boundaries
    if lower is None:
        subset = df[df['f'] < upper]
    elif upper is None:
        subset = df[df['f'] >= lower]
    else:
        subset = df[(df['f'] >= lower) & (df['f'] < upper)]
        
    row_count = len(subset)
    ax = axes[i]
    
    # Plot bars and scatter points only if there is data in this subset
    if not subset.empty:
        # Calculate the average for p1, p2, p3, p4 using ALL rows in the subset
        means = subset[variables].mean()
        
        # Plot the average as bar charts
        ax.bar(x_pos, means, color=colors, alpha=0.5, edgecolor='black', zorder=2)
        
        # --- NEW CODE: Subsample to max 1000 rows for the scatter plots ---
        if row_count > 1000:
            # random_state=42 ensures the sampled points look the same every time you run the script
            subset_scatter = subset.sample(n=1000, random_state=42)
        else:
            subset_scatter = subset
        # ------------------------------------------------------------------

        # Overlay the individual data points using the sampled subset
        for j, var in enumerate(variables):
            y_vals = subset_scatter[var].values
            # Add a slight random horizontal jitter so points don't entirely overlap
            x_vals = np.random.normal(x_pos[j], 0.06, size=len(y_vals))
            
            # Scatter plot for individual points
            # Set rasterized=True to further compress PDF size if 1000 points is still too large
            ax.scatter(x_vals, y_vals, color=colors[j], edgecolor='black', 
                       alpha=0.8, s=25, zorder=3)
            
    # Subplot formatting
    # Write the formula and the true number of rows found on top of the subset
    ax.set_title(f'{label}  (n={row_count})', fontsize=14, fontweight='bold')
    
    ax.set_xticks(x_pos)
    ax.set_xticklabels(variables)
    ax.grid(axis='y', linestyle='--', alpha=0.7, zorder=1)
    
    # Set Y label only for the first column of each row
    if i % 3 == 0:
        ax.set_ylabel('Probabilities', fontsize=14)

# Add a main title to the figure
#fig.suptitle('Averages and Individual Points of p1-p4 Grouped by f ranges', fontsize=18)

# 5. Save the figure to a PDF file
output_filename = 'output_subsets.pdf'
plt.savefig(output_filename, format='pdf', bbox_inches='tight')
plt.close()

print(f"Plot successfully saved to {output_filename}")