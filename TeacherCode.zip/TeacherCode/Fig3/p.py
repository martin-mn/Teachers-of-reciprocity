import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.axes_grid1 import make_axes_locatable

# Increase all font sizes globally
plt.rcParams.update({
    'font.size': 16,          # General/Default font size
    'axes.titlesize': 22,     # Title font size
    'axes.labelsize': 18,     # X/Y and Colorbar label font size
    'xtick.labelsize': 14,    # X tick label size
    'ytick.labelsize': 14,    # Y tick label size
})

# 1. Read the data from c.out with 4 columns
df = pd.read_csv('c.out', sep='\s+', names=['x', 'y', 'g', 'f'])

# 2. Pivot the data to create 2D matrices for both 'g' and 'f'
grid_g = df.pivot(index='y', columns='x', values='g')
grid_f = df.pivot(index='y', columns='x', values='f')

# Sort the y-indexes in descending order so smaller 'y' values are at the bottom
grid_g = grid_g.sort_index(ascending=False)
grid_f = grid_f.sort_index(ascending=False)

# 3. Initialize the plot with 1 row and 2 columns
fig, axes = plt.subplots(1, 2, figsize=(14, 7))

# 4. Generate the first heatmap for 'g' on axes[0]
divider_g = make_axes_locatable(axes[0])
cax_g = divider_g.append_axes("right", size="5%", pad=0.15)

sns.heatmap(
    grid_g, 
    cmap='coolwarm', 
    square=True, 
    vmin=0, vmax=1,      # <--- Fixed limits for the first heatmap
    ax=axes[0], 
    cbar_ax=cax_g 
    #cbar_kws={'label': 'Disciples'}
)
axes[0].set_title('Followers', pad=15)
axes[0].set_xlabel('p')
axes[0].set_ylabel('q')

# 5. Generate the second heatmap for 'f' on axes[1]
divider_f = make_axes_locatable(axes[1])
cax_f = divider_f.append_axes("right", size="5%", pad=0.15)

sns.heatmap(
    grid_f, 
    cmap='viridis', 
    square=True, 
    vmin=0, vmax=1,      # <--- Fixed limits for the second heatmap
    ax=axes[1], 
    cbar_ax=cax_f 
    #cbar_kws={'label': 'Payoff'} 
)
axes[1].set_title('Payoff', pad=15)
axes[1].set_xlabel('p')
axes[1].set_ylabel('q')

# Adjust layout to prevent overlapping labels/colorbars
plt.tight_layout()

# 6. Save the plot as a PDF file
plt.savefig('heatmaps_side_by_side.pdf', format='pdf', bbox_inches='tight')

print("Side-by-side heatmaps saved successfully as 'heatmaps_side_by_side.pdf'")