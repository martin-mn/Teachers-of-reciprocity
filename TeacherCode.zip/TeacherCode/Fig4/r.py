import pandas as pd

# Read the data (assuming whitespace separator and no headers in the file)
df = pd.read_csv('c.out', sep='\s+', header=None)

# Name the columns to make the filtering logic easy to read
df.columns = ['x1', 'x2', 'x3', 'x4', 'x5']

# 1. Sort all data by the 5th column (x5) in descending order
df_sorted = df.sort_values(by='x5', ascending=False)

# Write the fully sorted data to d.out
df_sorted.to_csv('d.out', sep='\t', index=False, header=False)

print("Data successfully written to d.out")