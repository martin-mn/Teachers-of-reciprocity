* N players: indirect reciprocity
* WF pairwise comparison

      program sab
      implicit real*8 (a-h,o-z)
      character*10 slurm
      
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)

      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (mm=1000,be=0.5d+00)
      parameter (c=0.5d+00,u=0.1d+00*rrn)
      parameter (itend=100000,init=itend/2)
        
      dimension y(n),p(n),q(n),f(n),yn(n),pn(n),qn(n)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      iseed=500+isl
      call init_genrand(iseed)

      open (unit=3,file=slurm)

* number of teachers 

      isum=0

      do m=0,2
      do im=1,20
      isum=isum+1
      if (isl.eq.isum) goto 15
      enddo
      enddo

 15   continue

      m1=m+1
    
      
* initial population    

      z =o0
      ex=o0 
 
      do i=1,m
      y(i)=0.9999d+00
      p(i)=0.9999d+00
      q(i)=0.0100d+00
      enddo 

      do i=m1,n      
      y(i)=genrand_real3()
      p(i)=genrand_real3()
      q(i)=genrand_real3()
      enddo
       


* learning dynamics

      do it=1,itend 

* calculate payoff

      call pay (y,p,q,f,x,n,mm,c)

* sample 

      if (it.gt.init) then
      z=z+o1
      ex=ex+x     
      endif

* update all players i=m1,n with PW comparison or mutation

      do i=m1,n 
  
      if (genrand_real3().lt.u) then 

      
      yn(i)=genrand_real3()
      pn(i)=genrand_real3()
      qn(i)=genrand_real3()      
            

      else 

      j = 1 + int(genrand_real3()*rn)

      prob=o1/(o1+dexp(-be*(f(j)-f(i))))

      if (genrand_real3().lt.prob) then

      
      yn(i)=y(j)
      pn(i)=p(j)
      qn(i)=q(j)

      else  

      
      yn(i)=y(i)
      pn(i)=p(i)
      qn(i)=q(i)
      
      endif
      endif


      enddo


* new generation i=m1,n

      do i=m1,n      
      y(i)=yn(i)
      p(i)=pn(i)
      q(i)=qn(i)      
      enddo
 
      enddo 


* output

      
      ex=ex/z

      write (3,'(i8,f12.8)') m,ex
      call flush(3)

      stop
      end



******************************************

      subroutine pay (y,p,q,f,x,n,m,c)
c
c     Indirect reciprocity simulation.
c
c     Output:
c       f(i) = payoff sums
c       x    = fraction of interactions that were cooperative
c
      integer n,m
      double precision y(n),p(n),q(n),f(n),c,x

      integer i,j,k
      integer r(n)
      integer ncoop
      double precision u, prob
      double precision genrand_real3
      external genrand_real3

c     Initialize reputations and payoffs
      do i = 1,n
      r(i) = 0
      f(i) = 0.0d0
      enddo

      ncoop = 0

c     Perform m random donor-recipient interactions
      do k = 1, m

c        Choose donor i uniformly from {1,...,n}
         i = int( genrand_real3() * dble(n) ) + 1

c        Choose recipient j uniformly from {1,...,n}, j .ne. i
   20    j = int( genrand_real3() * dble(n) ) + 1
         if (j .eq. i) goto 20

c        Cooperation probability depends on recipient reputation


c         if (r(j) .eq.  0) prob = y(i)
c         if (r(j) .eq.  1) prob = p(i)
c         if (r(j) .eq. -1) prob = q(i)
         
         if (r(j).eq.1) then
         prob=p(i)
         else if (r(j).eq.-1) then
         prob=q(i)
         else if (r(j).eq.0) then
         prob=y(i)
         endif

c        Donor action
         u = genrand_real3()
         if (u .lt. prob) then
c           Cooperate
            ncoop = ncoop + 1
            f(i) = f(i) - c
            f(j) = f(j) + 1.0d0
            r(i) = 1
         else
c           Defect
            r(i) = -1
         endif

      enddo

c     Fraction cooperative
      if (m .gt. 0) then
         x = dble(ncoop) / dble(m)
      else
         x = 0.0d0
      endif

      return
      end