import pandas as pd
import matplotlib.pyplot as plt

plt.rc('xtick', labelsize=14) 
plt.rc('ytick', labelsize=14)

# 1. Define filenames
input_file = 'o3.out'
output_file = 'time_series_plot.pdf'

# 2. Read the data
# We assume the columns are separated by spaces or tabs (sep='\s+').
# If your file has a header row (e.g., "Time Payoff"), change header=None to header=0
try:
    df = pd.read_csv(input_file, sep='\s+', header=None)
    
    # Assign names to the columns for clarity
    df.columns = ['Time', 'Scaled Payoff']

    # 3. Create the plot
    plt.figure(figsize=(6, 4)) # Set the figure size (width, height in inches)
    
    plt.plot(df['Time'], df['Scaled Payoff'], color='blue', linestyle='-', linewidth=1.5)
    
    # 4. Customize the plot
    plt.title('c = 0.95, one GTFT teacher', fontsize=14)
    plt.xlabel('Time', fontsize=14)
    plt.ylabel('Payoff', fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.7) # Add a subtle grid
    
    plt.tight_layout() # Ensures labels don't get cut off in the PDF
    
    # 5. Save the plot as a PDF
    plt.savefig(output_file, format='pdf')
    print(f"Plot successfully saved to {output_file}")
    
    # Clear the plot from memory
    plt.close()

except FileNotFoundError:
    print(f"Error: The file '{input_file}' was not found in the current directory.")
except Exception as e:
    print(f"An error occurred: {e}")