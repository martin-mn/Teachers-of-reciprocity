import matplotlib.pyplot as plt
import numpy as np

# File names, labels for the legend, and 5 distinct colors
input_files = ['GTFT.out', 'Partner.out', 'TFT.out', '1xxx.out', 'Rival.out']
labels = ['GTFT', 'Partner', 'TFT', '1xxx', 'Rival']
colors = ['blue', 'green', 'red', 'orange', 'purple']

output_file = 'output.pdf'

try:
    # Create the figure
    plt.figure(figsize=(6, 4))

    # Loop through each file, load the data, and plot its curve
    for file, label, color in zip(input_files, labels, colors):
        # Load the data
        data = np.loadtxt(file)
        
        # Extract columns (assuming 1st column is X, 2nd column is Y)
        x = data[:, 0]
        y = data[:, 1]

        # Plot y versus x (using a line and markers, applying the specific color and label)
        plt.plot(x, y, marker='o', linestyle='-', color=color, label=label)

    # Set the X-axis to a logarithmic scale
    plt.xscale('log')

    # Set the Y-axis limits between 0 and 1
    plt.ylim(0, 1)

    # Add labels and a title
    plt.xlabel('Probability of teacher update, $v_T$')
    plt.ylabel('Payoff')
    plt.title('Start with a single teacher under selection')

    # Add a legend to distinguish the 5 curves
    plt.legend()

    # Add a grid for better readability (especially useful for log scales)
    plt.grid(True, which="both", linestyle="--", linewidth=0.5)

    # Save the plot as a PDF
    # bbox_inches='tight' ensures that labels aren't cut off in the saved file
    plt.savefig(output_file, format='pdf', bbox_inches='tight')
    
    print(f"Success! Plot has been saved as {output_file}")

    # Close the plot to free up memory
    plt.close()

except FileNotFoundError as e:
    print(f"Error: One of the input files was not found. Details: {e}")
except Exception as e:
    print(f"An error occurred: {e}")