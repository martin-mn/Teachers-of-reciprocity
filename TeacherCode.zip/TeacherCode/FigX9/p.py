import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches

# --- Configuration ---
input_filename = 'c.out'  # Replace with your actual file name
output_filename = 'output_plot.pdf'

# 1. Read the data
df = pd.read_csv(input_filename, sep='\s+', header=None, names=['x', 'y'])

# 2. Calculate the average 'y' for each 'x'
avg_df = df.groupby('x')['y'].mean().reset_index()

# 3. Create the plot
plt.figure(figsize=(8, 6))

# Define exactly 3 colors for the 3 bars
colors = ['#1f77b4', '#ff7f0e', '#2ca02c'] # Blue, Orange, Green

# Map the unique 'x' values to positions 0, 1, and 2 for even spacing
unique_x = avg_df['x'].tolist()
x_positions = np.arange(len(unique_x))

# Draw the bar chart representing the averages
plt.bar(x_positions, avg_df['y'], color=colors, alpha=0.7, edgecolor='black', zorder=2, width=0.6)

# Create a mapping dictionary to align raw data points with their new bar positions
x_map = {val: i for i, val in enumerate(unique_x)}
mapped_raw_x = df['x'].map(x_map)

# Add horizontal "jitter" to the data points so they don't completely overlap
jitter_width = 0.15
jittered_x = mapped_raw_x + np.random.uniform(-jitter_width, jitter_width, size=len(df))

# Draw the individual data points on top of the bars
plt.scatter(jittered_x, df['y'], color='black', alpha=0.6, s=25, zorder=3)

# 4. Add labels, title, and formatting
plt.xlabel("Number of Teachers", fontsize=12)
plt.ylabel("Probability of cooperation", fontsize=12)
plt.title("Teachers in indirect reciprocity", fontsize=14)

# Set the x-ticks to display your actual 'x' values instead of 0, 1, 2
plt.xticks(x_positions, unique_x)

# Create a custom legend 
bar_legend = mpatches.Patch(color='gray', alpha=0.7, label='Average')
scatter_legend = plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='black', 
                            markersize=7, alpha=0.6, label='Individual Data')
plt.legend(handles=[bar_legend, scatter_legend])

# Set up grid (only on the y-axis for bar charts)
plt.grid(axis='y', linestyle='--', alpha=0.6, zorder=0)

# 5. Save to PDF and optionally display
plt.tight_layout() # Ensures labels don't get cut off
plt.savefig(output_filename, format='pdf')
print(f"Plot successfully saved to {output_filename}")

# Uncomment the next line to have a window pop up and show the plot
# plt.show()