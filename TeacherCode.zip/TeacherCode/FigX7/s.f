* N players: M1 strategies with discounting 
* WF pairwise comparison

      program sab
      implicit real*8 (a-h,o-z)
      common /para/ rr,ss,d,dd

      character*10 slurm
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)

      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (be=10.d+00,beta=be*rrn1)
      parameter (itend=10**4,init=itend/2)
      parameter (u=0.1d+00*rrn)

        
      dimension p0(n),p1(n),p2(n),p3(n),p4(n),f(n)
      dimension p0n(n),p1n(n),p2n(n),p3n(n),p4n(n)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      iseed=8000+isl
      call init_genrand(iseed)

      open (unit=3,file=slurm)

* different c and discount values  

      isum=0

      do idisc=1,3 

      dd=10.d+00**dble(-idisc)
      d=o1-dd

      do ic=2,10
      if (ic.lt.10) then
      c=dfloat(ic)*0.1d+00
      else
      c=0.95d+00
      endif       
      isum=isum+1
      if (isl.eq.isum) goto 15
      enddo

      enddo

 15   continue


* parameters 

      rr=o1-c
      ss=-c   

* initial    

      z=o0
      eff=o0   
      
* different runs

      do irun=1,100
      
* one GTFT teachers 

      p0(1)=0.9999d+00
      p1(1)=0.9999d+00
      p2(1)=0.0100d+00 
      p3(1)=0.9999d+00   
      p4(1)=0.0100d+00
       

* the others 
     

      do i=2,n
      p0(i)=genrand_real3()
      p1(i)=genrand_real3()
      p2(i)=genrand_real3()
      p3(i)=genrand_real3()
      p4(i)=genrand_real3()      
      enddo 


* learning dynamics

      do it=0,itend 

      do i=1,n
      f(i)=o0
      enddo

      do i=1,n
      do j=1,i-1

      call pay(p0(i),p1(i),p2(i),p3(i),p4(i),
     & p0(j),p1(j),p2(j),p3(j),p4(j),f1,f2)

      f(i)=f(i)+f1
      f(j)=f(j)+f2

      enddo
      enddo

* sample 

      if (it.gt.init) then
      z=z+o1
      do i=1,n
      eff=eff+f(i)
      enddo
      endif

* update all players i=2,n

      do i=2,n 

* player i mutates with prob u 

      if (genrand_real3().lt.u) then 
      p0n(i)=genrand_real3()
      p1n(i)=genrand_real3()
      p2n(i)=genrand_real3()    
      p3n(i)=genrand_real3()    
      p4n(i)=genrand_real3()        
      
      else  

      j = 1 + int(genrand_real3()*rn)
      prob=o1/(o1+dexp(-beta*(f(j)-f(i))))
      if (genrand_real3().lt.prob) then
      p0n(i)=p0(j)
      p1n(i)=p1(j)
      p2n(i)=p2(j)
      p3n(i)=p3(j)
      p4n(i)=p4(j)
      else 
      p0n(i)=p0(i)
      p1n(i)=p1(i)
      p2n(i)=p2(i)
      p3n(i)=p3(i)
      p4n(i)=p4(i)

      endif
      endif

      enddo


* new generation i=2,n

      do i=2,n
      p0(i)=p0n(i)
      p1(i)=p1n(i)
      p2(i)=p2n(i)
      p3(i)=p3n(i)
      p4(i)=p4n(i)      
      enddo
 
      enddo

      enddo 


* output

      
      eff=eff*rrn*rrn1/(z*(o1-c))
      
      write (3,'(3f12.8)') c,dd,eff

      call flush(3)

      stop
      end


********************************


* determinant formula: M1 with discounting

      subroutine pay(p0,p1,p2,p3,p4,q0,q1,q2,q3,q4,f1,f2)
      implicit real*8 (a-h,o-z)
      common /para/ rr,ss,d,dd 
      parameter (o0=0.d+00,o1=1.d+00)
      parameter (tt=o1,pp=o0)
      dimension am(4,4)

      am(1,1)= -o1 +d*p1*q1 +dd*p0*q0
      am(1,2)= -o1 +d*p1 +dd*p0
      am(1,3)= -o1 +d*q1 +dd*q0
      am(1,4)= rr

      am(2,1)= d*p2*q3 +dd*p0*q0
      am(2,2)= -o1 +d*p2 +dd*p0
      am(2,3)= d*q3 +dd*q0
      am(2,4)= ss

      am(3,1)= d*p3*q2 +dd*p0*q0
      am(3,2)= d*p3 +dd*p0
      am(3,3)= -o1 +d*q2 +dd*q0
      am(3,4)= tt

      am(4,1)= d*p4*q4 +dd*p0*q0
      am(4,2)= d*p4 +dd*p0
      am(4,3)= d*q4 +dd*q0
      am(4,4)= pp

      d1=det4(am)

      am(2,4)= tt
      am(3,4)= ss

      d2=det4(am)

      am(1,4)= o1
      am(2,4)= o1
      am(3,4)= o1
      am(4,4)= o1

      dnum=det4(am)

      f1=d1/dnum
      f2=d2/dnum

      return
      end


***



      
      function det3(a)
      implicit real*8 (a-h,o-z)
      dimension a(3,3)
      d=a(1,1)*a(2,2)*a(3,3)-a(1,1)*a(2,3)*a(3,2)-a(1,2)*a(2,1)*a(3,3)
      d=d+a(1,2)*a(2,3)*a(3,1)+a(1,3)*a(2,1)*a(3,2)
      det3=d-a(1,3)*a(2,2)*a(3,1)
      return
      end

***

      function det4(a)
      implicit real*8 (a-h,o-z)
      dimension a(4,4),b(3,3)

      do i=1,3
      do j=1,3
      b(i,j)=a(i+1,j+1)
      enddo
      enddo 

      d1=det3(b)

      b(1,1)=a(2,1)
      b(2,1)=a(3,1)
      b(3,1)=a(4,1)

      d2=det3(b)

      b(1,2)=a(2,2)
      b(2,2)=a(3,2)
      b(3,2)=a(4,2)

      d3=det3(b)

      b(1,3)=a(2,3)
      b(2,3)=a(3,3)
      b(3,3)=a(4,3)

      d4=det3(b)

      det4=a(1,1)*d1-a(1,2)*d2+a(1,3)*d3-a(1,4)*d4

      return
      end