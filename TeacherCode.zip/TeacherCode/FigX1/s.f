* N players: Reactive
* WF pairwise comparison

      program sab
      implicit real*8 (a-h,o-z)
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)

      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (c=0.95d+00,u=0.1d+00*rrn,be=10.d+00,beta=be*rrn1)
      parameter (itend=10**7,inter=10**3)
      parameter (pt1=0.9999d+00,qt1=0.01d+00)
        
      dimension p(n),q(n),r(n),f(n),pn(n),qn(n)

      iseed=42
      call init_genrand(iseed)

      open (unit=3,file='o3.out')

      iz=0

      m1=2
      
* initial population    
      
      p(1)=pt1
      q(1)=qt1
      r(1)=p(1)-q(1)
      
      do i=m1,n
      p(i)=genrand_real3()
      q(i)=genrand_real3()
      r(i)=p(i)-q(i)
      enddo 

* learning dynamics

      do it=0,itend 

* calculate payoff, do not play against self

      do i=1,n
      f(i)=o0
      enddo

      do i=1,n      
      do j=1,i-1      

      den=o1/(o1-r(i)*r(j))
      s1=(q(j)*r(i)+q(i))*den
      s2=(q(i)*r(j)+q(j))*den

      f(i)=f(i)+s2-c*s1
      f(j)=f(j)+s1-c*s2

      enddo
      enddo

* output 

      if (it.ge.iz) then
      iz=iz+inter
      eff=o0
      do i=1,n      
      eff=eff+f(i)
      enddo
      eff=eff*rrn*rrn1/(o1-c)
      write (3,'(i10,f16.8)') it,eff
      endif

* update all players i=m1,n with PW comparison or mutation

      do i=m1,n 
  
      if (genrand_real3().lt.u) then 

      pn(i)=genrand_real3()      
      qn(i)=genrand_real3()      

      else 

      j = 1 + int(genrand_real3()*rn)

      prob=o1/(o1+dexp(-beta*(f(j)-f(i))))

      if (genrand_real3().lt.prob) then
      pn(i)=p(j)
      qn(i)=q(j)
      else     
      pn(i)=p(i)
      qn(i)=q(i)      
      endif

      endif

      enddo

* new generation i=m1,n

      do i=m1,n
      p(i)=pn(i)
      q(i)=qn(i)
      r(i)=p(i)-q(i)
      enddo
 
      enddo 

* output      

      call flush(3)

      stop
      end