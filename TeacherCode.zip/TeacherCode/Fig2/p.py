import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
from mpl_toolkits.axes_grid1 import make_axes_locatable

# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size
    'axes.labelsize': 18,     # X and Y axis label font size
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})
# -------------------------------------

def process_file(filename):
    """Helper function to load data and format it into a and b grids."""
    data = np.loadtxt(filename)
    
    # Extract unique sorted u and v coordinates
    u_labels = sorted(set(data[:, 0]))
    v_labels = sorted(set(data[:, 1]))
    
    # Initialize grids for a and b
    a_grid = np.zeros((len(v_labels), len(u_labels)))
    b_grid = np.zeros((len(v_labels), len(u_labels)))
    
    # Populate the grids using u and v indices
    for u, v, a, b in data:
        u_idx = u_labels.index(u)
        v_idx = v_labels.index(v)
        a_grid[v_idx, u_idx] = a
        b_grid[v_idx, u_idx] = b
        
    # Reverse v_labels and grids for flipping the v-axis
    v_labels_reversed = v_labels[::-1]
    a_grid = a_grid[::-1, :]
    b_grid = b_grid[::-1, :]
    
    return a_grid, b_grid, u_labels, v_labels_reversed

# Process both input files
a_grid_1, b_grid_1, u_labels_1, v_labels_rev_1 = process_file('c1.out')
a_grid_2, b_grid_2, u_labels_2, v_labels_rev_2 = process_file('c2.out')

# Create and save the plots as a PDF
output_pdf = 'heatmaps_c1_c2.pdf'
with PdfPages(output_pdf) as pdf:
    # Set to a square proportion for a 2x2 grid
    fig = plt.figure(figsize=(14, 14))

    # ================= ROW 1: c1.out =================
    
    # c1.out - Heatmap for 'a' Values (Top Left)
    ax1 = plt.subplot(2, 2, 1)
    divider1 = make_axes_locatable(ax1)
    cax1 = divider1.append_axes("right", size="5%", pad=0.1) # Perfectly sizes colorbar
    sns.heatmap(a_grid_1, cmap='magma', annot=False, cbar=True, cbar_ax=cax1,
                xticklabels=u_labels_1, yticklabels=v_labels_rev_1, 
                vmin=0, vmax=1, square=True, ax=ax1)
    ax1.set_title('Cooperation rate')
    ax1.set_xlabel('u')
    ax1.set_ylabel('v')

    # c1.out - Heatmap for 'b' Values (Top Right)
    ax2 = plt.subplot(2, 2, 2)
    divider2 = make_axes_locatable(ax2)
    cax2 = divider2.append_axes("right", size="5%", pad=0.1)
    sns.heatmap(b_grid_1, cmap='viridis', annot=False, cbar=True, cbar_ax=cax2,
                xticklabels=u_labels_1, yticklabels=v_labels_rev_1, 
                vmin=0, vmax=1, square=True, ax=ax2)
    ax2.set_title('Payoff')
    ax2.set_xlabel('u')
    ax2.set_ylabel('v')

    # ================= ROW 2: c2.out =================
    
    # c2.out - Heatmap for 'a' Values (Bottom Left)
    ax3 = plt.subplot(2, 2, 3)
    divider3 = make_axes_locatable(ax3)
    cax3 = divider3.append_axes("right", size="5%", pad=0.1)
    sns.heatmap(a_grid_2, cmap='magma', annot=False, cbar=True, cbar_ax=cax3,
                xticklabels=u_labels_2, yticklabels=v_labels_rev_2, 
                vmin=0, vmax=1, square=True, ax=ax3)
    ax3.set_title('Cooperation rate')
    ax3.set_xlabel('u')
    ax3.set_ylabel('v')

    # c2.out - Heatmap for 'b' Values (Bottom Right)
    ax4 = plt.subplot(2, 2, 4)
    divider4 = make_axes_locatable(ax4)
    cax4 = divider4.append_axes("right", size="5%", pad=0.1)
    sns.heatmap(b_grid_2, cmap='viridis', annot=False, cbar=True, cbar_ax=cax4,
                xticklabels=u_labels_2, yticklabels=v_labels_rev_2, 
                vmin=0, vmax=1, square=True, ax=ax4)
    ax4.set_title('Payoff')
    ax4.set_xlabel('u')
    ax4.set_ylabel('v')
    
    # Adjust layout for better spacing
    plt.tight_layout()
    
    # Save the figure into the PDF
    pdf.savefig(fig)
    plt.close()

print(f"PDF file '{output_pdf}' created successfully.")