import matplotlib.pyplot as plt
import numpy as np
import os

# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size
    'axes.labelsize': 18,     # X and Y axis label font size
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})
# -------------------------------------

# Define the colors and names for the 5 c values (to match the previous setup)
colors = ['red', 'blue', 'green', 'orange', 'purple']
custom_names = ['c=0.70', 'c=0.75', 'c=0.80', 'c=0.85', 'c=0.90']

# Create a new figure (same size as before)
plt.figure(figsize=(8, 4))

filename = 'c.out'

if os.path.exists(filename):
    # Load the data (Column 0: c, Column 1: N)
    data = np.loadtxt(filename)
    N_vals = data[:, 1]
    
    # Draw horizontal bar chart 
    # zorder=3 keeps the bars on top of the grid lines
    plt.barh(custom_names, N_vals, color=colors, zorder=3)
    
else:
    print(f"Warning: The file named '{filename}' was not found.")

# Add aesthetics to the plot
plt.title('One teacher suffices up to')
plt.xlabel('Population size, N')
plt.ylabel('Cost, c')

# Add grid (zorder=0 pushes it behind the bars)
plt.grid(True, zorder=0)

# Save the plot as a PDF file
output_pdf = 'output_plot.pdf'
plt.savefig(output_pdf, format='pdf', bbox_inches='tight')

print(f"Plot successfully saved as '{output_pdf}'")

# Close the plot to free up memory
plt.close()