import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Read the data
df = pd.read_csv('c.out', sep='\s+', names=['u_T1', 'u_T2', 'f'], header=None)

# 2. Fix floating-point precision issues
df['u_T1'] = df['u_T1'].round(8)
df['u_T2'] = df['u_T2'].round(8)

# 3. Pivot the data to create a 2D matrix
heatmap_data = df.pivot(index='u_T2', columns='u_T1', values='f')

# Sort axes to ensure correct ascending order
heatmap_data.sort_index(axis=0, inplace=True)
heatmap_data.sort_index(axis=1, inplace=True)

# Extract coordinates and grid values
X = heatmap_data.columns.values
Y = heatmap_data.index.values
Z = heatmap_data.values

# 4. Calculate exact logarithmic boundaries for the grid cells
# Since your coordinates double at each step, the geometric boundary 
# around each point is exactly sqrt(2). This creates N+1 perfect log boundaries.
factor = np.sqrt(2)
X_edges = np.append([X[0] / factor], X * factor)
Y_edges = np.append([Y[0] / factor], Y * factor)

# 5. Create the plot
fig, ax = plt.subplots(figsize=(4, 4))

# Create the heatmap using our custom X_edges and Y_edges
# (We remove shading='nearest' because providing exact edges does this automatically)
mesh = ax.pcolormesh(X_edges, Y_edges, Z, cmap='viridis', vmin=0, vmax=1)

# 6. Set both axes to logarithmic scale
ax.set_xscale('log')
ax.set_yscale('log')

# 7. Add colorbar (spanning 0 to 1)
cbar = fig.colorbar(mesh, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label('Payoff', rotation=270, labelpad=15)

# 8. Add labels and title
ax.set_xlabel('$u_{Partner}$')
ax.set_ylabel('$u_{Rival}$')
ax.set_title('Mutation, selection: Partner vs Rival')

# 9. Force the plot to be a perfect square
ax.set_box_aspect(1)

# 10. Save the output to a PDF file
plt.savefig('heatmap.pdf', format='pdf', bbox_inches='tight')

print("Success: Heatmap with uniform square sizes saved to 'heatmap.pdf'")