import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator # Add this to your imports at the top of your script


# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size (e.g., 'No teacher')
    'axes.labelsize': 18,     # X and Y axis label font size ('Cost, c', 'Payoff')
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})
# -------------------------------------


def plot_time_series():
    # 1. Read the data
    # sep='\s+' handles spaces or tabs. If your file is comma-separated, use sep=','
    columns = ['time', 'n', 'm', 'f']
    try:
        df = pd.read_csv('c.out', sep='\s+', names=columns)
    except FileNotFoundError:
        print("Error: The file 'c.out' was not found.")
        return

    # 2. Create the figure and subplots (1 row, 3 columns)
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    # 3. Plot n vs time (Line plot)
    axes[0].plot(df['time'], df['n'], color='blue')
    axes[0].set_title('')
    axes[0].set_xlabel('Time')
    axes[0].set_ylabel('Followers')
    axes[0].grid(True)

    
# 4. Plot m vs time (Scatter plot, no lines)
# Using .scatter() ensures only data points are drawn
    axes[1].scatter(df['time'], df['m'], color='green', marker='o', s=35) # s changes dot size
    axes[1].set_title('')
    axes[1].set_xlabel('Time')
    axes[1].set_ylabel('Disciples')

# Force the y-axis to only display integer ticks
    axes[1].yaxis.set_major_locator(MaxNLocator(integer=True))

    axes[1].grid(True)

    # 5. Plot f vs time (Line plot)
    axes[2].plot(df['time'], df['f'], color='red')
    axes[2].set_title('')
    axes[2].set_xlabel('Time')
    axes[2].set_ylabel('Payoff')
    axes[2].grid(True)

    # 6. Adjust layout so plots don't overlap
    plt.tight_layout()

    # 7. Save to PDF
    output_filename = 'time_series_plots.pdf'
    plt.savefig(output_filename, format='pdf')
    print(f"Plot successfully saved to {output_filename}")

if __name__ == "__main__":
    plot_time_series()