* N players: M1; no teacher
* WF pairwise comparison

      program sb
      implicit real*8 (a-h,o-z)
      character*10 slurm
      common /para/ sss,ttt
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)
      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (u=1.d-03,beta=0.3d+00)
        
      dimension p(n,4),ff(n,n),f(n),ss(n,n),pn(n,4),p1(4),p2(4)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      iseed=6000+isl
      call init_genrand(iseed)

      open (unit=3,file=slurm)

      itend=10**6
      init=itend/100

* value of u and v 

      i=0
      
      do iu=-40,40,4
      do iv=-40,40,4
      i=i+1
      if (i.eq.isl) goto 28
      enddo
      enddo 

 28   continue
      uu=dfloat(iu)*0.1d+00      
      vv=dfloat(iv)*0.1d+00

      sss=uu
      ttt=vv+o1

      z=o0
      erate=o0
      ephi=o0

* initial population 

      do i=1,n
      do k=1,4
      p(i,k)=genrand_real3()
      enddo
      enddo 

* no teacher   

* learning dynamics

      do it=0,itend 

      do i=1,n
      do j=1,i-1

      do k=1,4
      p1(k)=p(i,k)
      p2(k)=p(j,k)
      enddo

      call pay(p1,p2,f1,f2,s1,s2)

      ff(i,j)=f1
      ff(j,i)=f2 

      ss(i,j)=s1
      ss(j,i)=s2

      enddo
      enddo

      do i=1,n
      ff(i,i)=o0
      ss(i,i)=o0
      enddo
     
* fitness, cooperationrate 

      phi=o0
      rate=o0
      do i=1,n
      f(i)=o0
      do j=1,n
      f(i)=f(i)+ff(i,j)
      rate=rate+ss(i,j)
      enddo
      f(i)=f(i)*rrn1
      phi=phi+f(i)
      enddo

* sample 

      if (it.gt.init) then
      z=z+o1
      erate=erate+rate
      ephi=ephi+phi
      endif


* update all players with PW comparison or mutation


      do i=1,n 

      if (genrand_real3().lt.u) then 
      do k=1,4
      pn(i,k)=genrand_real3()
      enddo

      else 

      j=nint(genrand_real3()*rn+oh)

      prob=o1/(o1+dexp(-beta*(f(j)-f(i))))

      ran=genrand_real3() 
      if (ran.lt.prob) then

      do k=1,4
      pn(i,k)=p(j,k)
      enddo
      else 

      do k=1,4
      pn(i,k)=p(i,k)
      enddo
      endif

      endif

      enddo


* new generation 

      do i=1,n
      do k=1,4
      p(i,k)=pn(i,k)
      enddo
      enddo
 
      enddo 


* output

      dn=o1/(z*rn)
      ephi=ephi*dn


      dn=dn*rrn1
      erate=erate*dn

      em=(o1+uu+vv)*oh
      emax=o1
      if (em.gt.emax) emax=em
      emin=o0
      if (em.lt.emin) emin=em

      ephi=(ephi-emin)/(emax-emin)


      write (3,'(4f12.8)') uu,vv,erate,ephi
      call flush(3)

     
      stop
      end


***** payoff for M1 strategies

      subroutine pay(p1,p2,f1,f2,s1,s2)
      implicit real*8 (a-h,o-z)
      common /para/ ss,tt

      dimension p1(4),p2(4)
      parameter (o1=1.d+00)

C     --- 1. Extract elements of the first 3 columns into scalars ---
      a11 = p1(1)*p2(1) - o1
      a21 = p1(2)*p2(3)
      a31 = p1(3)*p2(2)
      a41 = p1(4)*p2(4)

      a12 = p1(1) - o1
      a22 = p1(2) - o1
      a32 = p1(3)
      a42 = p1(4)

      a13 = p2(1) - o1
      a23 = p2(3)
      a33 = p2(2) - o1
      a43 = p2(4)

C     --- 2. Compute common 2x2 subexpressions ---
      t34_23 = a32*a43 - a33*a42
      t34_13 = a31*a43 - a33*a41
      t34_12 = a31*a42 - a32*a41

      t24_23 = a22*a43 - a23*a42
      t24_13 = a21*a43 - a23*a41
      t24_12 = a21*a42 - a22*a41

      t23_23 = a22*a33 - a23*a32
      t23_13 = a21*a33 - a23*a31
      t23_12 = a21*a32 - a22*a31

C     --- 3. Compute the 4 cofactors of the 4th column ---
C     Note the alternating signs inherent to Laplace expansion
      c14 = -(a21*t34_23 - a22*t34_13 + a23*t34_12)
      c24 =  (a11*t34_23 - a12*t34_13 + a13*t34_12)
      c34 = -(a11*t24_23 - a12*t24_13 + a13*t24_12)
      c44 =  (a11*t23_23 - a12*t23_13 + a13*t23_12)

C     --- 4. Compute the 5 required determinants as dot products ---
C     dnum: 4th col = (1, 1, 1, 1)
      dnum = c14 + c24 + c34 + c44
      rnum = o1 / dnum

C     f1: 4th col = (rr, ss, tt, pp) = (1, ss, tt, 0)
      f1 = (c14 + ss*c24 + tt*c34) * rnum

C     f2: 4th col = (rr, tt, ss, pp) = (1, tt, ss, 0)
      f2 = (c14 + tt*c24 + ss*c34) * rnum

C     s1: 4th col = (1, 1, 0, 0)
      s1 = (c14 + c24) * rnum

C     s2: 4th col = (1, 0, 1, 0)
      s2 = (c14 + c34) * rnum

      return
      end