import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
import os

# --- INCREASED FONT SIZES GLOBALLY ---
plt.rcParams.update({
    'font.size': 16,          # General/default font size
    'axes.titlesize': 20,     # Subplot title font size (e.g., 'No teacher')
    'axes.labelsize': 18,     # X and Y axis label font size ('Cost, c', 'Payoff')
    'xtick.labelsize': 14,    # X-axis tick numbers/labels
    'ytick.labelsize': 14     # Y-axis tick numbers/labels
})
# -------------------------------------


# Define filenames, colors, and distinct marker symbols for the points
filenames = ['1', '2', '3', '4', '5']
colors = ['red', 'blue', 'green', 'orange', 'purple']
markers = ['o', 's', '^', 'D', 'v']  # circle, square, triangle, diamond, down-triangle
custom_names = ['c=0.70', 'c=0.75', 'c=0.80', 'c=0.85', 'c=0.90']

# Create a new figure
plt.figure(figsize=(8, 4))

# Open a text file to write the linear regression formulas
with open('regression_formulas.txt', 'w') as f_out:
    f_out.write("Linear Regression Formulas (calculated for y > 1)\n")
    f_out.write("-" * 55 + "\n")

    # Loop through files, colors, and markers
    for filename, color, marker, name in zip(filenames, colors, markers, custom_names):
        if os.path.exists(filename):
            # Load the data
            data = np.loadtxt(filename)
            x = data[:, 0]
            y = data[:, 1]
            
            # 1. Plot the original curve with lines AND symbols (markers)
            # zorder=3 keeps the main data on top of the regression lines
            plt.plot(x, y, color=color, marker=marker, markersize=5, 
                     linestyle='-', label=name, zorder=3)
            
            # 2. Filter data: Ignore y values that are 1 or less
            valid_indices = y > 1
            x_filtered = x[valid_indices]
            y_filtered = y[valid_indices]
            
            # 3. Perform linear regression (needs at least 2 points)
            if len(x_filtered) > 1:
                # np.polyfit with degree 1 returns slope (m) and intercept (b)
                m, b = np.polyfit(x_filtered, y_filtered, 1)
                
                # Write formula to the text file
                sign = "+" if b >= 0 else "-"
                f_out.write(f"File {filename}: y = {m:.4f}x {sign} {abs(b):.4f}\n")
                
                # Calculate the regression line points over the original x-range
                y_reg = m * x + b
                
                # Plot the regression line in subdued grey
                # alpha=0.6 makes it slightly transparent, zorder=1 pushes it to the back
                plt.plot(x, y_reg, color='gray', linestyle='--', alpha=0.6, zorder=1)
            else:
                f_out.write(f"File {filename}: Not enough data points (y > 1) for regression.\n")
                
        else:
            print(f"Warning: The file named '{filename}' was not found.")

# Add aesthetics to the plot
plt.title('How many teachers are needed?')
plt.xlabel('Population size, N')
plt.ylabel('Number of teachers')

# Force Y-axis ticks to be integers
plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True))

plt.legend()
plt.grid(True, zorder=0)

# Save the plot as a PDF file
output_pdf = 'output_plot.pdf'
plt.savefig(output_pdf, format='pdf', bbox_inches='tight')

print(f"Plot successfully saved as '{output_pdf}'")
print("Regression formulas successfully saved to 'regression_formulas.txt'")

# Close the plot to free up memory
plt.close()