import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Read the data from your specific file format
df = pd.read_csv('c.out', sep='\s+', names=['u_T1', 'u_T2', 'f'], header=None)

# 2. Fix floating-point precision issues to prevent white squares
df['u_T1'] = df['u_T1'].round(8)
df['u_T2'] = df['u_T2'].round(8)

# 3. Pivot the data to create a 2D matrix
heatmap_data = df.pivot(index='u_T2', columns='u_T1', values='f')

# Sort axes to ensure correct ascending order
heatmap_data.sort_index(axis=0, inplace=True)
heatmap_data.sort_index(axis=1, inplace=True)

# Extract axes and grid values
X = heatmap_data.columns.values
Y = heatmap_data.index.values
Z = heatmap_data.values

# 4. Create the plot
fig, ax = plt.subplots(figsize=(4, 4))

# Create the heatmap
# Added vmin=0 and vmax=1 to lock the colorbar range exactly between 0 and 1
mesh = ax.pcolormesh(X, Y, Z, cmap='viridis', shading='nearest', vmin=0, vmax=1)

# 5. Set both axes to logarithmic scale
ax.set_xscale('log')
#ax.set_yscale('log')

# 6. Add colorbar
cbar = fig.colorbar(mesh, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label('Payoff', rotation=270, labelpad=15)

# 7. Add labels and title
ax.set_xlabel('Mutation rate, $u_{T}$')
ax.set_ylabel('Quality, $q$')
ax.set_title('Mutation, selection of inaccurate teachers')

# 8. Force the plot to be a perfect square
ax.set_box_aspect(1)

# 9. Save the output to a PDF file
plt.savefig('heatmap.pdf', format='pdf', bbox_inches='tight')

print("Success: Heatmap safely rendered and saved to 'heatmap.pdf'")