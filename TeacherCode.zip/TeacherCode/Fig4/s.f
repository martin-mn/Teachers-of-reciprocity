* N players: M1 
* WF pairwise comparison

      program sab
      implicit real*8 (a-h,o-z)
      common /para/ rr,ss

      character*10 slurm
      
      parameter (o0=0.d+00,oh=0.5d+00,o1=1.d+00,o2=2.d+00)
      parameter (n=100,rn=dfloat(n),rrn=o1/rn,rrn1=o1/dfloat(n-1))
      parameter (c=0.8d+00,cc=c/(o1-c),factor=rrn*rrn1/(o1-c))
      parameter (be=10.d+00,beta=be*rrn1)
      parameter (itend=10**4)
      parameter (u=0.1d+00*rrn)
        
      dimension p1(n),p2(n),p3(n),p4(n),f(n),pt(11)
      dimension p1n(n),p2n(n),p3n(n),p4n(n)

      call get_command_argument(1,slurm)
      slurm=trim(adjustl(slurm))
      read(slurm,*) isl

      open (unit=3,file=slurm)

      iseed=8000+isl
      call init_genrand(iseed)

* parameters 

      rr=o1-c
      ss=-c

* many teachers 

      do i4=1,100 

      p1(1)=0.9999d+00
      p2(1)=genrand_real3()
      p3(1)=genrand_real3()
      p4(1)=genrand_real3()
     
* initial  

      z=o0
      eff=o0

* 10 runs per teacher

      do irun=1,10

* the others 
     
      do i=2,n
      p1(i)=genrand_real3()
      p2(i)=genrand_real3()
      p3(i)=genrand_real3()
      p4(i)=genrand_real3()      
      enddo 


* learning dynamics

      do it=0,itend 

      do i=1,n
      f(i)=o0
      enddo

      do i=1,n
      do j=1,i-1

      call pay(p1(i),p2(i),p3(i),p4(i),p1(j),p2(j),p3(j),p4(j),f1,f2)

      f(i)=f(i)+f1
      f(j)=f(j)+f2

      enddo
      enddo

* sample 

      z=z+o1
      do i=1,n
      eff=eff+f(i)
      enddo

* update all players i=2,n

      do i=2,n 

* player i mutates with prob u 

      if (genrand_real3().lt.u) then 
      p1n(i)=genrand_real3()
      p2n(i)=genrand_real3()    
      p3n(i)=genrand_real3()    
      p4n(i)=genrand_real3()        
      
      else  

      j = 1 + int(genrand_real3()*rn)
      prob=o1/(o1+dexp(-beta*(f(j)-f(i))))
      if (genrand_real3().lt.prob) then
      p1n(i)=p1(j)
      p2n(i)=p2(j)
      p3n(i)=p3(j)
      p4n(i)=p4(j)
      else 
      p1n(i)=p1(i)
      p2n(i)=p2(i)
      p3n(i)=p3(i)
      p4n(i)=p4(i)

      endif
      endif

  
      

      enddo


* new generation i=2,n

      do i=2,n
      p1(i)=p1n(i)
      p2(i)=p2n(i)
      p3(i)=p3n(i)
      p4(i)=p4n(i)      
      enddo
 
      enddo 

      enddo


* output
      
      eff=eff*factor/z
      
      write(3,'(5f12.8)') p1(1),p2(1),p3(1),p4(1),eff
      
      enddo

      call flush(3)


      stop
      end


*********************** payoff for M1


      subroutine pay(p1,p2,p3,p4,q1,q2,q3,q4,f1,f2)
C************************************************************
C*  Optimized payoff using column-4 cofactors
C*  Only columns 1-3 enter the 3x3 minors used for all three
C*  determinants (denominator, d1, d2).
C************************************************************
      implicit real*8 (a-h,o-z)
      common /para/ rr,ss
      parameter (o0=0.d+00,o1=1.d+00)
      
      
      double precision a11,a21,a31,a41,
     &                 a12,a22,a32,a42,
     &                 a13,a23,a33,a43
      double precision c23x,c23y,c23z,
     &                 c24x,c24y,c24z,
     &                 c34x,c34y,c34z
      double precision m14,m24,m34,m44
      double precision dnum,d1,d2,rnum

C     Build first three columns of base matrix
      a11 = p1*q1 - o1
      a21 = p2*q3
      a31 = p3*q2
      a41 = p4*q4

      a12 = p1 - o1
      a22 = p2 - o1
      a32 = p3
      a42 = p4

      a13 = q1 - o1
      a23 = q3
      a33 = q2 - o1
      a43 = q4

C     Cross products of row vectors (columns 1-3 only)
C     r2 x r3
      c23x = a22*a33 - a23*a32
      c23y = a23*a31 - a21*a33
      c23z = a21*a32 - a22*a31

C     r2 x r4
      c24x = a22*a43 - a23*a42
      c24y = a23*a41 - a21*a43
      c24z = a21*a42 - a22*a41

C     r3 x r4
      c34x = a32*a43 - a33*a42
      c34y = a33*a41 - a31*a43
      c34z = a31*a42 - a32*a41

C     3x3 minors for column 4:
C     M44 = det(rows 1,2,3)
C     M34 = det(rows 1,2,4)
C     M24 = det(rows 1,3,4)
C     M14 = det(rows 2,3,4)
      m44 = a11*c23x + a12*c23y + a13*c23z
      m34 = a11*c24x + a12*c24y + a13*c24z
      m24 = a11*c34x + a12*c34y + a13*c34z
      m14 = a21*c34x + a22*c34y + a23*c34z

C     Determinant with last column = (1,1,1,1)^T
C     det = -a14*M14 + a24*M24 - a34*M34 + a44*M44
C     For a14=a24=a34=a44=1:
      dnum = -m14 + m24 - m34 + m44

C     First payoff: last column = (rr,ss,tt,pp)
C     and rr=1, pp=0 by PARAMETER:
C      d1   = -rr*m14 + ss*m24 - tt*m34

      d1   = -rr*m14 + ss*m24 - m34


C     Second payoff: last column = (rr,tt,ss,pp)
C      d2   = -rr*m14 + tt*m24 - ss*m34

      d2   = -rr*m14 + m24 - ss*m34

      rnum = o1/dnum
      f1   = d1*rnum
      f2   = d2*rnum

      return
      end