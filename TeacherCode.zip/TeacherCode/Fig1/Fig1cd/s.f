* N players: reactive strategies
* WF pairwise comparison
* m is number of teachers 

        program sab
        implicit real*8 (a-h,o-z)
        character(len=10) :: slurm
       
        real*8,  parameter :: o0=0.d0, oh=0.5d0, o1=1.d0, o2=2.d0
        integer, parameter :: nn=20000, nl=10
        real*8,  parameter :: be=10.d0, beta=be/dble(2*nl)
        integer, parameter :: itend=10**5, init=itend/2
        integer, parameter :: nruns=20
        real*8,  parameter :: pt=0.9999d0, qt=0.01d0
       
        real*8  :: p(nn), q(nn), r(nn), f(nn), pn(nn), qn(nn)
        integer :: neigh(nn,nl)
       
        call get_command_argument(1,slurm)
        slurm = trim(adjustl(slurm))
        read(slurm,*) isl
       
        iseed = 523 + isl
        call init_genrand(iseed)
       
        open (unit=3,file=slurm)
       
        c = 0.7d0 + dble(isl-1)*0.05d0
       
        min = 0
        max = 50
       
        do in=1,20
       
           n    = in*1000
           rn   = dfloat(n)
           rrn  = o1/rn
           u    = 0.1d0*rrn
       
           do i=1,n
              do k=1,nl
                 j = i + k
                 if (j.gt.n) j = j - n
                 neigh(i,k) = j
              end do
           end do
       
           do m=min,max
       
              m1 = m+1
       
              eff_sum = o0
       
              do irun=1,nruns
       
                 z   = o0
                 eff = o0
       
                 do i=1,m
                    p(i)=pt
                    q(i)=qt
                    r(i)=p(i)-q(i)
                 end do
       
                 do i=m1,n
                    p(i)=genrand_real3()
                    q(i)=genrand_real3()
                    r(i)=p(i)-q(i)
                 end do
       
                 do it=1,itend
       
                    f(1:n) = o0
       
                    do i=1,n
                       ri = r(i)
                       qi = q(i)
       
                       do k=1,nl
                          j  = neigh(i,k)
                          rj = r(j)
                          qj = q(j)
       
                          den = o1/(o1 - ri*rj)
                          s1  = (qj*ri + qi)*den
                          s2  = (qi*rj + qj)*den
       
                          f(i) = f(i) + s2 - c*s1
                          f(j) = f(j) + s1 - c*s2
                       end do
                    end do
       
                    if (it.gt.init) then
                       z   = z + o1
                       eff = eff + sum(f(1:n))
                    end if
       
                    do i=m1,n
       
                       if (genrand_real3().lt.u) then
       
                          pn(i)=genrand_real3()
                          qn(i)=genrand_real3()
       
                       else
       
                          j = 1 + int(genrand_real3()*rn)
       
                          prob = o1/(o1 + dexp(-beta*(f(j)-f(i))))
       
                          if (genrand_real3().lt.prob) then
                             pn(i)=p(j)
                             qn(i)=q(j)
                          else
                             pn(i)=p(i)
                             qn(i)=q(i)
                          end if
       
                       end if
       
                    end do
       
                    do i=m1,n
                       p(i)=pn(i)
                       q(i)=qn(i)
                       r(i)=p(i)-q(i)
                    end do
       
                 end do
       
                 eff_run = eff*rrn/z
                 eff_run = eff_run/(dble(2*nl)*(o1-c))
       
                 eff_sum = eff_sum + eff_run
       
              end do
       
              eff = eff_sum/dble(nruns)
       
              if (eff.gt.0.5d0) then
                 write (3,'(2i8)') n,m
                 call flush(3)
                 goto 65
              end if
       
           end do
       
   65      continue
           min = m-1
       
        end do
       
        stop
        end program sab